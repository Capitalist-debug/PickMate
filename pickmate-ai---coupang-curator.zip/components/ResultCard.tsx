import React from 'react';
import { ExternalLink, ShoppingCart, Tag, Star, Copy, Check } from 'lucide-react';
import { ProductRecommendation } from '../types';

interface ResultCardProps {
  item: ProductRecommendation;
  delay: number;
  affiliateId?: string;
}

const ResultCard: React.FC<ResultCardProps> = ({ item, delay, affiliateId }) => {
  const [copied, setCopied] = React.useState(false);

  // Construct Coupang Search URL
  let searchUrl = `https://www.coupang.com/np/search?component=&q=${encodeURIComponent(item.searchKeywords)}&channel=user`;
  
  if (affiliateId) {
    searchUrl += `&affiliate_id=${affiliateId}`; 
  }

  const handleCopy = () => {
    navigator.clipboard.writeText(item.searchKeywords);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Generate a soft background color based on the first char of category to give some variety
  const getBgColor = (cat: string) => {
    const colors = ['bg-red-50', 'bg-blue-50', 'bg-green-50', 'bg-purple-50', 'bg-yellow-50', 'bg-pink-50'];
    return colors[cat.length % colors.length];
  };

  const bgColor = getBgColor(item.category);

  return (
    <div 
      className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden hover:shadow-xl transition-all duration-500 animate-fadeIn transform hover:-translate-y-1"
      style={{ animationDelay: `${delay}ms`, animationFillMode: 'both' }}
    >
      <div className="flex flex-col h-full">
        {/* Visual Header */}
        <div className={`h-32 ${bgColor} flex items-center justify-center relative overflow-hidden`}>
          <div className="text-6xl filter drop-shadow-sm transform hover:scale-110 transition-transform duration-300 cursor-default">
            {item.emoji}
          </div>
          <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-full text-xs font-bold text-gray-600 shadow-sm flex items-center gap-1">
             <Tag size={10} /> {item.category}
          </div>
        </div>

        {/* Content Body */}
        <div className="p-5 flex flex-col flex-grow">
          <div className="flex justify-between items-start mb-2">
             <h3 className="text-lg font-bold text-gray-800 leading-tight">
              {item.productName}
            </h3>
          </div>
          
          <div className="mb-4">
             <span className="text-xl font-extrabold text-red-600 tracking-tight">{item.priceEstimate}</span>
          </div>

          <div className="bg-gray-50 rounded-xl p-4 mb-5 flex-grow border border-gray-100 relative">
             <div className="absolute -top-3 left-3 bg-white px-2 py-0.5 rounded-full text-xs font-bold text-blue-600 border border-blue-100 flex items-center gap-1 shadow-sm">
                <Star size={10} fill="currentColor" /> AI 추천 이유
             </div>
            <p className="text-gray-700 text-sm leading-relaxed pt-1">
              "{item.reason}"
            </p>
          </div>

          <div className="flex gap-2 mt-auto">
             <button
                onClick={handleCopy}
                className="flex items-center justify-center p-3 rounded-xl border border-gray-200 text-gray-500 hover:bg-gray-50 hover:text-gray-800 transition-colors"
                title="검색어 복사하기"
             >
                {copied ? <Check size={18} className="text-green-500"/> : <Copy size={18} />}
             </button>
            <a
                href={searchUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white font-bold py-3.5 px-4 rounded-xl transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-2 group relative overflow-hidden"
            >
                <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
                <ShoppingCart size={18} className="relative z-10" />
                <span className="relative z-10">
                {affiliateId ? '쿠팡 최저가 확인' : '쿠팡 보러가기'}
                </span>
                <ExternalLink size={14} className="opacity-70 relative z-10 group-hover:translate-x-1 transition-transform" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResultCard;