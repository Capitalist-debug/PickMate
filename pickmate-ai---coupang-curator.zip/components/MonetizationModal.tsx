import React, { useState, useEffect } from 'react';
import { X, DollarSign, Settings, Rocket, Globe, ExternalLink, Key } from 'lucide-react';

interface MonetizationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveId: (id: string) => void;
  currentId: string;
}

type TabType = 'guide' | 'settings' | 'deploy' | 'marketing';

const MonetizationModal: React.FC<MonetizationModalProps> = ({ isOpen, onClose, onSaveId, currentId }) => {
  const [activeTab, setActiveTab] = useState<TabType>('guide');
  const [inputId, setInputId] = useState(currentId);

  useEffect(() => {
    setInputId(currentId);
  }, [currentId]);

  if (!isOpen) return null;

  const handleSave = () => {
    onSaveId(inputId);
    alert('저장되었습니다! 이제 추천 상품 클릭 시 해당 ID가 사용됩니다.');
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="bg-gray-900 text-white p-5 flex justify-between items-center flex-shrink-0">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <DollarSign className="text-yellow-400" />
            PickMate 비즈니스 센터
          </h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors">
            <X size={24} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-100 overflow-x-auto flex-shrink-0">
          {[
            { id: 'guide', label: '수익 원리', icon: <DollarSign size={16}/> },
            { id: 'settings', label: 'ID 설정', icon: <Settings size={16}/> },
            { id: 'deploy', label: '배포/운영', icon: <Globe size={16}/> },
            { id: 'marketing', label: '홍보 꿀팁', icon: <Rocket size={16}/> },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as TabType)}
              className={`flex-1 py-3 px-4 font-medium text-sm transition-colors whitespace-nowrap flex items-center justify-center gap-2 ${
                activeTab === tab.id 
                  ? 'text-red-600 border-b-2 border-red-600 bg-red-50' 
                  : 'text-gray-500 hover:text-gray-50'
              }`}
            >
              {tab.icon}
              {tab.label}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto">
          {activeTab === 'guide' && (
            <div className="space-y-6">
              <div className="bg-blue-50 p-4 rounded-xl border border-blue-100">
                <h3 className="font-bold text-blue-900 mb-2">💰 수익화 구조 요약</h3>
                <p className="text-sm text-blue-800 leading-relaxed">
                  1. 사용자가 내 사이트에서 상품 추천을 받음<br/>
                  2. '구매하기' 버튼 클릭 (쿠팡으로 이동)<br/>
                  3. 24시간 내 구매 발생 시 <strong>구매액의 3%</strong> 수익 지급
                </p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
                <div className="p-4 bg-gray-50 rounded-xl">
                    <div className="bg-white w-10 h-10 rounded-full flex items-center justify-center mx-auto mb-2 shadow-sm text-red-500 font-bold">1</div>
                    <div className="text-sm font-bold text-gray-700">트래픽 유입</div>
                    <div className="text-xs text-gray-500 mt-1">SNS/커뮤니티</div>
                </div>
                <div className="p-4 bg-gray-50 rounded-xl">
                    <div className="bg-white w-10 h-10 rounded-full flex items-center justify-center mx-auto mb-2 shadow-sm text-red-500 font-bold">2</div>
                    <div className="text-sm font-bold text-gray-700">AI 큐레이션</div>
                    <div className="text-xs text-gray-500 mt-1">구매 전환율 UP</div>
                </div>
                <div className="p-4 bg-gray-50 rounded-xl">
                    <div className="bg-white w-10 h-10 rounded-full flex items-center justify-center mx-auto mb-2 shadow-sm text-red-500 font-bold">3</div>
                    <div className="text-sm font-bold text-gray-700">수익 정산</div>
                    <div className="text-xs text-gray-500 mt-1">쿠팡 파트너스</div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'settings' && (
            <div className="space-y-6">
              <div className="text-center">
                <h3 className="text-lg font-bold text-gray-800">파트너스 ID 연결</h3>
                <p className="text-sm text-gray-500 mt-1">
                  수익을 정산받을 쿠팡 파트너스 ID를 입력해주세요.
                </p>
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-bold text-gray-700">ID 입력 (예: AF1234567)</label>
                <div className="flex gap-2">
                    <input
                    type="text"
                    value={inputId}
                    onChange={(e) => setInputId(e.target.value)}
                    placeholder="AF..."
                    className="flex-grow px-4 py-3 rounded-xl border border-gray-300 focus:border-red-500 outline-none font-mono text-lg"
                    />
                    <button onClick={handleSave} className="bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-xl whitespace-nowrap">
                        저장
                    </button>
                </div>
              </div>

              <div className="bg-gray-50 p-4 rounded-xl border border-gray-100 flex flex-col gap-3">
                  <div className="flex items-center gap-2 text-sm font-semibold text-gray-700">
                      <Key size={16} />
                      <span>아직 아이디가 없다면?</span>
                  </div>
                  <a 
                    href="https://partners.coupang.com" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-2 w-full bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 font-medium py-2 rounded-lg transition-colors text-sm"
                  >
                      쿠팡 파트너스 가입하러 가기 <ExternalLink size={14}/>
                  </a>
              </div>
            </div>
          )}

          {activeTab === 'deploy' && (
            <div className="space-y-5">
              <div className="bg-green-50 p-4 rounded-xl border border-green-100">
                <h3 className="font-bold text-green-900 mb-1">🌍 무료로 내 앱 배포하기</h3>
                <p className="text-sm text-green-800">
                  <strong>Vercel</strong>을 사용하면 이 앱을 평생 무료로 운영할 수 있습니다.
                  배포 시 반드시 <strong>Gemini API 키</strong>가 필요합니다.
                </p>
              </div>
              
              <div className="space-y-4 text-sm text-gray-600">
                 <div className="flex gap-3 items-start">
                    <div className="w-6 h-6 rounded-full bg-gray-200 flex items-center justify-center font-bold text-xs flex-shrink-0 mt-0.5">1</div>
                    <div className="flex-grow">
                        <p className="font-bold text-gray-800">Gemini API 키 발급</p>
                        <p className="mb-2">Google AI Studio에서 무료 키를 받으세요.</p>
                        <a 
                            href="https://aistudio.google.com/app/apikey" 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 bg-blue-600 text-white text-xs px-3 py-1.5 rounded-md hover:bg-blue-700"
                        >
                            키 발급받기 <ExternalLink size={10}/>
                        </a>
                    </div>
                </div>

                <div className="flex gap-3 items-start">
                    <div className="w-6 h-6 rounded-full bg-gray-200 flex items-center justify-center font-bold text-xs flex-shrink-0 mt-0.5">2</div>
                    <div>
                      <p className="font-bold text-gray-800">코드 업로드 (GitHub)</p>
                      <p>현재 프로젝트 파일들을 GitHub 저장소에 올립니다.</p>
                    </div>
                </div>
                <div className="flex gap-3 items-start">
                    <div className="w-6 h-6 rounded-full bg-gray-200 flex items-center justify-center font-bold text-xs flex-shrink-0 mt-0.5">3</div>
                    <div>
                        <p className="font-bold text-gray-800">Vercel 배포 & 환경변수 설정</p>
                        <p>Vercel에서 프로젝트를 생성할 때, <strong>Environment Variables</strong>에 다음을 꼭 추가하세요.</p>
                        <div className="mt-2 bg-gray-800 text-gray-200 p-2 rounded font-mono text-xs">
                            Name: API_KEY<br/>
                            Value: [발급받은 AI 키]
                        </div>
                    </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'marketing' && (
            <div className="space-y-6">
              <h3 className="font-bold text-gray-800">🚀 트래픽 폭발시키는 숏폼 아이디어</h3>
              
              <div className="border border-gray-200 rounded-xl p-4 hover:shadow-md transition-shadow">
                <div className="flex items-center gap-2 mb-2 text-red-600 font-bold">
                    <Rocket size={18} />
                    <span>컨셉 1: 결정장애 해결사</span>
                </div>
                <p className="text-sm text-gray-600 mb-2">
                    "여친 생일 선물 3시간째 검색 중? 🤯<br/>
                    AI한테 예산이랑 나이만 말하면 3초 만에 찾아줌. 이거 봐 ㄷㄷ"
                </p>
                <div className="bg-gray-50 px-3 py-2 rounded text-xs text-gray-500">
                    #선물추천 #기념일선물 #AI쇼핑 #꿀팁
                </div>
              </div>

              <div className="border border-gray-200 rounded-xl p-4 hover:shadow-md transition-shadow">
                <div className="flex items-center gap-2 mb-2 text-red-600 font-bold">
                    <Rocket size={18} />
                    <span>컨셉 2: 최악의 선물 피하기</span>
                </div>
                <p className="text-sm text-gray-600 mb-2">
                    "집들이 갈 때 휴지 좀 그만 사! 🧻🚫<br/>
                    센스 있는 3만 원대 선물, AI가 골라준 거 들고 갔더니 칭찬 받음."
                </p>
                <div className="bg-gray-50 px-3 py-2 rounded text-xs text-gray-500">
                    #집들이선물 #센스있는선물 #자취꿀템
                </div>
              </div>
              
              <div className="text-xs text-gray-400 text-center">
                * 인스타그램/유튜브 프로필 링크(Link in Bio)에<br/> 내 사이트 주소를 걸어두는 것 잊지 마세요!
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};

export default MonetizationModal;