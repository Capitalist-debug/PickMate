import React from 'react';
import { ShoppingBag, Sparkles, Wallet } from 'lucide-react';

interface HeaderProps {
  onOpenSettings: () => void;
}

const Header: React.FC<HeaderProps> = ({ onOpenSettings }) => {
  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-3xl mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="bg-red-500 p-2 rounded-lg text-white">
            <ShoppingBag size={24} />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900 tracking-tight">PickMate AI</h1>
            <p className="text-xs text-gray-500 font-medium">스마트 쇼핑 큐레이터</p>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-1 text-sm font-medium text-red-500 bg-red-50 px-3 py-1 rounded-full">
            <Sparkles size={14} />
            <span>Powered by Gemini</span>
            </div>
            
            <button 
                onClick={onOpenSettings}
                className="flex items-center gap-2 text-sm font-medium text-gray-600 hover:text-gray-900 bg-gray-100 hover:bg-gray-200 px-3 py-2 rounded-lg transition-colors"
                title="수익화 설정"
            >
                <Wallet size={16} />
                <span className="hidden xs:inline">비즈니스 설정</span>
            </button>
        </div>
      </div>
    </header>
  );
};

export default Header;