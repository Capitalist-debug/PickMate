import React, { useState } from 'react';
import { Search, Loader2, Sparkles } from 'lucide-react';
import { FormData, BUDGET_OPTIONS, RECIPIENT_OPTIONS, CATEGORY_OPTIONS } from '../types';

interface InputFormProps {
  onSubmit: (data: FormData) => void;
  isLoading: boolean;
}

const PRESETS = [
  { label: '🏠 센스있는 집들이', data: { recipient: 'friend', age: '30대', gender: 'any', category: 'home', budget: '50,000원 정도', occasion: '친구 신혼부부 집들이 선물', interests: '감성 인테리어' } },
  { label: '🎂 여친 생일', data: { recipient: 'partner', age: '20대 후반', gender: 'female', category: 'beauty', budget: '100,000원 정도', occasion: '여자친구 생일 기념일', interests: '요즘 유행하는 인기템' } },
  { label: '💪 부모님 효도', data: { recipient: 'parent', age: '60대', gender: 'any', category: 'food', budget: '100,000원 정도', occasion: '부모님 건강 챙기기', interests: '고급스러운 패키지' } },
  { label: '👶 조카 장난감', data: { recipient: 'child', age: '5살', gender: 'any', category: 'kids', budget: '30,000원 정도', occasion: '조카 선물', interests: '교육적이면서 재밌는 것' } },
];

const InputForm: React.FC<InputFormProps> = ({ onSubmit, isLoading }) => {
  const [formData, setFormData] = useState<FormData>({
    recipient: 'self',
    age: '',
    gender: 'any',
    category: 'all',
    occasion: '',
    budget: '50,000원 정도',
    interests: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const handleRecipientSelect = (id: string) => {
    setFormData(prev => ({ ...prev, recipient: id }));
  };

  const applyPreset = (presetData: any) => {
    setFormData({
        ...formData,
        ...presetData
    });
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl p-6 md:p-8 border border-gray-100">
      <div className="mb-6 text-center">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">무엇을 찾고 계신가요?</h2>
        <p className="text-gray-500">AI가 쿠팡의 수만 가지 상품 중 딱 맞는 것을 찾아드립니다.</p>
      </div>

      {/* Quick Presets */}
      <div className="mb-8">
        <p className="text-xs font-bold text-gray-400 mb-2 uppercase tracking-wider text-center">✨ 인기 테마 원클릭 완성</p>
        <div className="flex flex-wrap justify-center gap-2">
            {PRESETS.map((preset, idx) => (
                <button
                    key={idx}
                    onClick={() => applyPreset(preset.data)}
                    type="button"
                    className="flex items-center gap-1.5 bg-red-50 hover:bg-red-100 text-red-600 px-3 py-2 rounded-full text-sm font-medium transition-colors border border-red-100"
                >
                    <Sparkles size={12} />
                    {preset.label}
                </button>
            ))}
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        
        {/* Recipient Selection */}
        <div className="space-y-2">
          <label className="block text-sm font-semibold text-gray-700">누구를 위한 선물인가요?</label>
          <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
            {RECIPIENT_OPTIONS.map((option) => (
              <button
                key={option.id}
                type="button"
                onClick={() => handleRecipientSelect(option.id)}
                className={`flex flex-col items-center justify-center p-3 rounded-xl border transition-all ${
                  formData.recipient === option.id
                    ? 'border-red-500 bg-red-50 text-red-600 ring-1 ring-red-500'
                    : 'border-gray-200 hover:border-red-200 hover:bg-gray-50 text-gray-600'
                }`}
              >
                <span className="text-xl mb-1">{option.icon}</span>
                <span className="text-xs font-medium">{option.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Age */}
          <div className="space-y-2">
            <label className="block text-sm font-semibold text-gray-700">연령대</label>
            <input
              type="text"
              placeholder="예: 30대 초반, 7살"
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-red-500 focus:ring-2 focus:ring-red-200 outline-none transition-all"
              value={formData.age}
              onChange={(e) => setFormData({ ...formData, age: e.target.value })}
              required
            />
          </div>

          {/* Gender */}
          <div className="space-y-2">
            <label className="block text-sm font-semibold text-gray-700">성별</label>
            <div className="flex rounded-xl bg-gray-100 p-1">
              {[
                { val: 'male', label: '남성' },
                { val: 'female', label: '여성' },
                { val: 'any', label: '무관' }
              ].map((opt) => (
                <button
                  key={opt.val}
                  type="button"
                  onClick={() => setFormData({ ...formData, gender: opt.val as any })}
                  className={`flex-1 py-2 text-sm font-medium rounded-lg transition-all ${
                    formData.gender === opt.val
                      ? 'bg-white text-gray-900 shadow-sm'
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Category & Budget Group */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Category */}
            <div className="space-y-2">
                <label className="block text-sm font-semibold text-gray-700">원하는 카테고리</label>
                <select
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-red-500 focus:ring-2 focus:ring-red-200 outline-none transition-all bg-white"
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                >
                    {CATEGORY_OPTIONS.map((opt) => (
                    <option key={opt.value} value={opt.value}>{opt.label}</option>
                    ))}
                </select>
            </div>

            {/* Budget */}
            <div className="space-y-2">
                <label className="block text-sm font-semibold text-gray-700">예산</label>
                <select
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-red-500 focus:ring-2 focus:ring-red-200 outline-none transition-all bg-white"
                    value={formData.budget}
                    onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
                >
                    {BUDGET_OPTIONS.map((opt) => (
                    <option key={opt.value} value={opt.value}>{opt.label}</option>
                    ))}
                </select>
            </div>
        </div>

        {/* Occasion */}
        <div className="space-y-2">
          <label className="block text-sm font-semibold text-gray-700">목적 / 상황</label>
          <input
            type="text"
            placeholder="예: 집들이, 생일, 다이어트 시작, 재택근무"
            className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-red-500 focus:ring-2 focus:ring-red-200 outline-none transition-all"
            value={formData.occasion}
            onChange={(e) => setFormData({ ...formData, occasion: e.target.value })}
            required
          />
        </div>

         {/* Interests */}
         <div className="space-y-2">
          <label className="block text-sm font-semibold text-gray-700">추가 관심사 / 요청사항 (선택)</label>
          <input
            type="text"
            placeholder="예: 귀여운 스타일 좋아함, 실용적인 것 선호"
            className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-red-500 focus:ring-2 focus:ring-red-200 outline-none transition-all"
            value={formData.interests}
            onChange={(e) => setFormData({ ...formData, interests: e.target.value })}
          />
        </div>

        <button
          type="submit"
          disabled={isLoading}
          className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-4 px-6 rounded-xl transition-all transform hover:scale-[1.02] disabled:opacity-70 disabled:scale-100 flex items-center justify-center gap-2 shadow-lg shadow-red-200"
        >
          {isLoading ? (
            <>
              <Loader2 className="animate-spin" />
              <span>AI가 분석 중입니다...</span>
            </>
          ) : (
            <>
              <Search size={20} />
              <span>AI 추천 상품 보기</span>
            </>
          )}
        </button>
      </form>
    </div>
  );
};

export default InputForm;