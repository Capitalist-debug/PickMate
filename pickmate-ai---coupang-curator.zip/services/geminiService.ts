import { GoogleGenAI, Type, Schema } from "@google/genai";
import { FormData, ProductRecommendation } from '../types';

// Initialize Gemini
// NOTE: Process.env.API_KEY is handled by the runtime environment.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const responseSchema: Schema = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      productName: {
        type: Type.STRING,
        description: "The specific name of the recommended product (in Korean).",
      },
      priceEstimate: {
        type: Type.STRING,
        description: "An estimated price range in KRW (e.g., '35,000원').",
      },
      reason: {
        type: Type.STRING,
        description: "A persuasive reason why this product is perfect for the user's request (in Korean).",
      },
      category: {
        type: Type.STRING,
        description: "The product category (e.g., 'Electronics', 'Home Decor').",
      },
      searchKeywords: {
        type: Type.STRING,
        description: "Optimized keywords to search for this exact item on Coupang.",
      },
      emoji: {
        type: Type.STRING,
        description: "A single emoji that best represents this product (e.g., 💄, 💻, 👟).",
      }
    },
    required: ["productName", "priceEstimate", "reason", "category", "searchKeywords", "emoji"],
  },
};

export const generateRecommendations = async (formData: FormData): Promise<ProductRecommendation[]> => {
  const model = "gemini-2.5-flash";

  const categoryPrompt = formData.category === 'all' 
    ? "Any suitable category based on the context" 
    : `Strictly within the '${formData.category}' category`;

  const prompt = `
    You are a top-tier Korean shopping curator designed to help affiliate marketers.
    
    User Context:
    - Recipient: ${formData.recipient}
    - Age Group: ${formData.age}
    - Gender: ${formData.gender}
    - Occasion/Purpose: ${formData.occasion}
    - Budget: ${formData.budget}
    - Specific Interests/Notes: ${formData.interests}
    - Preferred Category: ${categoryPrompt}

    Task:
    Recommend 5 highly specific, popular, and high-rated products that are likely available on Coupang (Korea's largest e-commerce site).
    Do not suggest generic items like "Gift Card". Suggest tangible, shippable products.
    The 'reason' should be compelling and emotional to drive conversion.
    
    Output strictly in JSON format.
  `;

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: responseSchema,
        temperature: 0.7, // Creative but relevant
      },
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");

    const data = JSON.parse(text) as Omit<ProductRecommendation, 'id'>[];
    
    // Add IDs for React keys
    return data.map((item, index) => ({
      ...item,
      id: `rec-${Date.now()}-${index}`
    }));

  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error("Failed to generate recommendations. Please try again.");
  }
};