import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import InputForm from './components/InputForm';
import ResultCard from './components/ResultCard';
import MonetizationModal from './components/MonetizationModal';
import { FormData, ProductRecommendation, AppState } from './types';
import { generateRecommendations } from './services/geminiService';
import { AlertCircle, RotateCcw, Share2, Sparkles, ExternalLink } from 'lucide-react';

function App() {
  const [appState, setAppState] = useState<AppState>(AppState.IDLE);
  const [recommendations, setRecommendations] = useState<ProductRecommendation[]>([]);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [userInput, setUserInput] = useState<FormData | null>(null);
  
  // Monetization State
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [affiliateId, setAffiliateId] = useState('');

  // Load ID from local storage on mount
  useEffect(() => {
    const savedId = localStorage.getItem('coupang_partners_id');
    if (savedId) {
      setAffiliateId(savedId);
    }
  }, []);

  const handleSaveId = (id: string) => {
    setAffiliateId(id);
    localStorage.setItem('coupang_partners_id', id);
  };

  const handleFormSubmit = async (data: FormData) => {
    setAppState(AppState.LOADING);
    setErrorMsg(null);
    setRecommendations([]);
    setUserInput(data);

    try {
      const results = await generateRecommendations(data);
      setRecommendations(results);
      setAppState(AppState.RESULTS);
    } catch (error: any) {
      console.error(error);
      setErrorMsg(error.message || "추천을 불러오는 중 오류가 발생했습니다.");
      setAppState(AppState.ERROR);
    }
  };

  const handleReset = () => {
    setAppState(AppState.IDLE);
    setRecommendations([]);
    setErrorMsg(null);
    setUserInput(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleShare = () => {
    if (recommendations.length === 0) return;

    let text = `🎁 PickMate AI 맞춤 선물 추천 🎁\n\n`;
    if (userInput) {
        text += `대상: ${userInput.recipient} (${userInput.age})\n`;
        text += `예산: ${userInput.budget}\n\n`;
    }
    
    text += `👇 AI가 엄선한 BEST 5 👇\n`;
    
    recommendations.forEach((item, idx) => {
        text += `${idx + 1}. ${item.emoji} ${item.productName}\n`;
        text += `   ㄴ 💡 ${item.reason.substring(0, 30)}...\n`;
    });

    text += `\n더 자세한 정보와 최저가는 여기서 확인하세요!\n(이곳에 내 사이트 링크 입력)`;

    navigator.clipboard.writeText(text).then(() => {
      alert("📋 추천 리스트가 복사되었습니다!\n카카오톡이나 SNS에 바로 붙여넣기 하세요.");
    }).catch(err => {
      console.error('Failed to copy: ', err);
      alert("공유하기에 실패했습니다.");
    });
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 pb-20 font-sans">
      <Header onOpenSettings={() => setIsSettingsOpen(true)} />

      <MonetizationModal 
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        currentId={affiliateId}
        onSaveId={handleSaveId}
      />

      <main className="flex-grow max-w-3xl w-full mx-auto px-4 py-8">
        
        {/* Intro Banner */}
        {appState === AppState.IDLE && (
          <div className="mb-8 bg-gradient-to-r from-red-500 via-red-600 to-pink-600 rounded-3xl p-8 text-white shadow-xl relative overflow-hidden">
            <div className="relative z-10">
                <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-md px-3 py-1 rounded-full text-sm font-medium mb-3 border border-white/30">
                    <Sparkles size={14} className="text-yellow-300" />
                    <span>AI 쇼핑 마스터</span>
                </div>
                <h2 className="text-3xl font-bold mb-3 leading-tight">
                    선물 고민, <br/>
                    AI에게 물어보세요!
                </h2>
                <p className="opacity-90 text-red-50 font-medium">
                    복잡한 검색 없이 상황과 예산만 알려주세요.<br/>
                    실패 없는 쿠팡 꿀템을 찾아드립니다.
                </p>
            </div>
            {/* Decorative circles */}
            <div className="absolute top-[-50%] right-[-10%] w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
            <div className="absolute bottom-[-20%] left-[-10%] w-48 h-48 bg-yellow-400/20 rounded-full blur-2xl"></div>
          </div>
        )}

        {/* Form Section */}
        <div className={`transition-all duration-500 ${appState === AppState.RESULTS ? 'hidden' : 'block'}`}>
          <InputForm onSubmit={handleFormSubmit} isLoading={appState === AppState.LOADING} />
        </div>

        {/* Error State */}
        {appState === AppState.ERROR && (
          <div className="bg-red-50 border border-red-200 rounded-2xl p-8 text-center animate-fadeIn shadow-sm">
            <div className="flex justify-center mb-4 text-red-500">
              <AlertCircle size={48} />
            </div>
            <h3 className="text-xl font-bold text-gray-800 mb-2">잠시 문제가 발생했어요</h3>
            <p className="text-gray-600 mb-6">{errorMsg}</p>
            <button 
              onClick={() => setAppState(AppState.IDLE)}
              className="bg-white border border-gray-300 text-gray-700 font-bold py-3 px-8 rounded-xl hover:bg-gray-50 transition-colors shadow-sm"
            >
              다시 시도하기
            </button>
          </div>
        )}

        {/* Results Section */}
        {appState === AppState.RESULTS && (
          <div className="space-y-6 animate-fadeIn">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
              <div>
                <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2">
                   <span className="bg-red-100 text-red-600 px-2 py-1 rounded-md text-sm">추천 완료</span>
                   <span>총 {recommendations.length}개의 발견!</span>
                </h2>
                <p className="text-sm text-gray-500 mt-1">마음에 드는 상품을 클릭하여 확인하세요.</p>
              </div>
              
              <div className="flex gap-2 w-full sm:w-auto">
                <button 
                  onClick={handleShare}
                  className="flex-1 sm:flex-none flex items-center justify-center gap-2 text-sm font-bold text-white bg-[#FEE500] hover:bg-[#FDD835] text-black transition-colors px-4 py-3 rounded-xl shadow-sm"
                  title="카카오톡 등으로 공유하기"
                >
                  <Share2 size={16} />
                  <span>결과 공유</span>
                </button>
                <button 
                  onClick={handleReset}
                  className="flex-1 sm:flex-none flex items-center justify-center gap-2 text-sm font-bold text-gray-600 hover:text-gray-900 bg-gray-100 hover:bg-gray-200 transition-colors px-4 py-3 rounded-xl"
                >
                  <RotateCcw size={16} />
                  <span>처음으로</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {recommendations.map((item, index) => (
                <ResultCard 
                  key={item.id} 
                  item={item} 
                  delay={index * 150} 
                  affiliateId={affiliateId}
                />
              ))}
            </div>

            {/* General Coupang Banner - Catch Drop-off traffic */}
            <div className="mt-4 bg-gradient-to-r from-gray-900 to-gray-800 rounded-2xl p-6 text-white text-center shadow-lg transform transition-all hover:scale-[1.01]">
              <h3 className="text-lg font-bold mb-2 flex items-center justify-center gap-2">
                <Sparkles className="text-yellow-400" size={20}/>
                아직 고민되시나요?
              </h3>
              <p className="text-gray-300 text-sm mb-5">
                AI 추천 이외에도 쿠팡에는 수많은 할인 상품이 있어요.<br/>
                지금 진행 중인 와우 할인을 직접 확인해보세요!
              </p>
              <a 
                href={affiliateId ? `https://www.coupang.com?affiliate_id=${affiliateId}` : "https://www.coupang.com"}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-white text-gray-900 font-bold py-3.5 px-8 rounded-xl hover:bg-gray-100 transition-colors shadow-md"
              >
                <img src="https://image7.coupangcdn.com/image/coupang/favicon/v2/favicon.ico" className="w-5 h-5" alt="coupang" />
                쿠팡 홈 바로가기
                <ExternalLink size={14} className="opacity-50" />
              </a>
            </div>

            <div className="mt-4 p-5 bg-blue-50/50 rounded-2xl text-center text-sm border border-blue-100">
              <p className="text-blue-900 font-medium mb-1">💡 구매 팁</p>
              <p className="text-blue-700 opacity-80 mb-3">상품 가격은 판매자의 사정에 따라 실시간으로 변동될 수 있습니다.</p>
              <div className="text-xs text-gray-400">
                {affiliateId 
                  ? `파트너스 ID(${affiliateId})가 적용되었습니다.`
                  : "이 포스팅은 쿠팡 파트너스 활동의 일환으로, 이에 따른 일정액의 수수료를 제공받습니다."}
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="text-center py-8 text-gray-400 text-xs">
        <p className="mb-2">PickMate AI © 2024</p>
        <p>AI 쇼핑 큐레이션 서비스</p>
      </footer>

      {/* Tailwind Animation Styles */}
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(15px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fadeIn {
          animation-name: fadeIn;
          animation-duration: 0.6s;
          animation-fill-mode: both;
          animation-timing-function: cubic-bezier(0.16, 1, 0.3, 1);
        }
      `}</style>
    </div>
  );
}

export default App;