
export interface FormData {
  recipient: string;
  age: string;
  gender: 'male' | 'female' | 'any';
  category: string;
  occasion: string;
  budget: string;
  interests: string;
}

export interface ProductRecommendation {
  id: string;
  productName: string;
  priceEstimate: string;
  reason: string;
  category: string;
  searchKeywords: string;
  emoji: string;
}

export enum AppState {
  IDLE = 'IDLE',
  LOADING = 'LOADING',
  RESULTS = 'RESULTS',
  ERROR = 'ERROR'
}

export const BUDGET_OPTIONS = [
  { label: '1만원 이하', value: '10,000원 이하' },
  { label: '3만원 대', value: '30,000원 정도' },
  { label: '5만원 대', value: '50,000원 정도' },
  { label: '10만원 대', value: '100,000원 정도' },
  { label: '30만원 이상', value: '300,000원 이상' },
  { label: '상관없음', value: '가격 무관' },
];

export const CATEGORY_OPTIONS = [
  { value: 'all', label: '전체 (AI가 알아서 추천)' },
  { value: 'digital', label: '디지털 / 가전 (전자기기)' },
  { value: 'fashion', label: '패션 / 의류 / 잡화' },
  { value: 'beauty', label: '뷰티 / 화장품' },
  { value: 'home', label: '홈 / 인테리어 / 생활용품' },
  { value: 'food', label: '식품 / 간식 / 영양제' },
  { value: 'kitchen', label: '주방용품' },
  { value: 'kids', label: '유아동 / 장난감' },
  { value: 'sports', label: '스포츠 / 레저 / 캠핑' },
  { value: 'books', label: '도서 / 문구 / 취미' },
];

export const RECIPIENT_OPTIONS = [
  { id: 'self', label: '나 자신', icon: '👤' },
  { id: 'partner', label: '연인', icon: '❤️' },
  { id: 'parent', label: '부모님', icon: '👨‍👩‍👧' },
  { id: 'friend', label: '친구/동료', icon: '🎁' },
  { id: 'child', label: '자녀/조카', icon: '👶' },
];
